package com.uped.proyecto;

import com.uped.proyecto.modelo.Persona;
import com.uped.proyecto.modelo.Cliente;
import com.uped.proyecto.modelo.Visitante;
import com.uped.proyecto.modelo.Empleado;
import com.uped.proyecto.modelo.Estudiante;

public class Main {

    public static void main(String[] args) {

    // La superclase Persona y la palabra extends

        new Cliente("Ana López", "04512378-9", "7777-1234");

        //

        Visitante v = new Visitante("Kevin");
        System.out.println(v);

        //
        Empleado empleado = new Empleado("Luis Pérez", "06223456-1", 850.0);
        System.out.println(empleado.presentarse());
        empleado.actualizarNombre("Luis Pérez Martínez");
        System.out.println(empleado.presentarse());

        //
        Estudiante e = new Estudiante(
                "Carlos Ramírez", "06123456-7",
                "UPED-2026-045", "Ing. en Sistemas");

        System.out.println(e);
        e.matricular("Programación III");
    }
}


