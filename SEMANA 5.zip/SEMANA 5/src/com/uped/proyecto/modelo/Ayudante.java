package com.uped.proyecto.modelo;

public class Ayudante {
}
